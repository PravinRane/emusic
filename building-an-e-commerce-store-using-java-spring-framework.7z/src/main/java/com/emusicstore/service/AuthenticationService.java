package com.emusicstore.service;

public interface AuthenticationService {

	public boolean validateUser(String username,String password);
	
	public boolean resetPasswordForUser(String username, String password, String newPassword);
}
