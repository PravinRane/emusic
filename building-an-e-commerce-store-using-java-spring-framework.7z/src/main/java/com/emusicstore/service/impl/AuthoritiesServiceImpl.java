package com.emusicstore.service.impl;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.emusicstore.dao.AuthoritiesDao;
import com.emusicstore.service.AuthoritiesService;

@Service
public class AuthoritiesServiceImpl implements AuthoritiesService {

	@Autowired
	AuthoritiesDao dao;
	
	public String getAuthoritiesOfUser(String username) {
		// TODO Auto-generated method stub
		String authority = dao.getAuthoritiesOfUser(username);
		if(authority!=null){
			return authority;
		}
		return null;
	}

}
