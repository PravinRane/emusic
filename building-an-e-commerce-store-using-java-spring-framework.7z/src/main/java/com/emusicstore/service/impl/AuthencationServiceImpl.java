package com.emusicstore.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.emusicstore.dao.impl.UserAuthenticationDao;
import com.emusicstore.service.AuthenticationService;

@Service
public class AuthencationServiceImpl implements AuthenticationService {

	@Autowired
	UserAuthenticationDao dao;
	
	public boolean validateUser(String username,String password) {
		// TODO Auto-generated method stub
		
		if( dao.isValidUser(username, password))
		{
			return true;
		}
		
		return false;
	}

	public boolean resetPasswordForUser(String username, String password, String newPassword) {
		// TODO Auto-generated method stub
		
		if(dao.resetPasswordForUser(username, password, newPassword)){
			return true;
		}
		
		return false;
	}

}
