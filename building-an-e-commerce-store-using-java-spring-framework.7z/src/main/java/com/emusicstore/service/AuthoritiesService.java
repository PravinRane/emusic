package com.emusicstore.service;

public interface AuthoritiesService {

	public String getAuthoritiesOfUser(String user);
}
