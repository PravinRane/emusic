package com.emusicstore.dao.impl;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.emusicstore.dao.AuthoritiesDao;
import com.emusicstore.model.Authorities;

@Repository
public class AuthoritiesDaoImpl implements AuthoritiesDao {

	  @Autowired
	    private SessionFactory sessionFactory;
	public String getAuthoritiesOfUser(String username) {
		// TODO Auto-generated method stub
		   String defualtAuthority="admin";	
		   try{
		   Session session = sessionFactory.getCurrentSession();
		   Criteria cr = session.createCriteria(Authorities.class).
				   add(Restrictions.eq("username", username));
		   Authorities auth = (Authorities) cr.uniqueResult();
		   return auth.getAuthority();
		   }catch(Exception e){}
		return defualtAuthority;
	}

}
