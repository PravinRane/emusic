package com.emusicstore.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.emusicstore.model.Customer;
import com.emusicstore.model.Users;



@Repository
@Transactional
public class UserAuthenticationDao {

	@Autowired
    private SessionFactory sessionFactory;

	
	public boolean isValidUser(String username , String password){
		
		   Session session = sessionFactory.getCurrentSession();
	        Query query = session.createQuery("from Users u where u.username='"+username +"' and u.password='"+password+"'");
	        
	        List<Users> cus = query.list();
	        
	        if(cus.size()!=0){
	        	return true;
	        }
	        
	        
	        return false;
	}
	
	
	public boolean resetPasswordForUser(String username , String password, String newPassword){
		
		 Session session = sessionFactory.getCurrentSession();
	        Query query = session.createQuery("from Users u where u.username='"+username +"' and u.password='"+password+"'");
	        
	        List<Users> cusw =  query.list();
	        if(cusw!=null){
	        	Users cus = cusw.get(0);
	        	cus.setPassword(newPassword);
	        	session.save(cus);
	        	session.flush();
	        	return true;
	        }
	        
	        
		return false;
	}
	
	
}
