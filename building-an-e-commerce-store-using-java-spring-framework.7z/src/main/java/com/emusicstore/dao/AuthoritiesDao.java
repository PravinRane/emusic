package com.emusicstore.dao;

public interface AuthoritiesDao {

	public String getAuthoritiesOfUser(String username);
}
