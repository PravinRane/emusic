package com.emusicstore.controller;




import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.emusicstore.model.Authorities;
import com.emusicstore.model.Customer;
import com.emusicstore.model.Users;
import com.emusicstore.service.AuthenticationService;
import com.emusicstore.service.AuthoritiesService;
import com.emusicstore.service.impl.CustomerServiceImpl;

@Controller
public class HomeController {

	@Autowired
	AuthenticationService service;
	
	@Autowired
	CustomerServiceImpl cusservice;
	
	@Autowired
	AuthoritiesService authservice;
	
    @RequestMapping("/")
    public String home(){
        return "home";
    }

    @RequestMapping("/login")
    public ModelAndView login(
            @RequestParam(value="error", required = false)
            String error,
            @RequestParam(value="logout", required = false)
            String logout,
            Model model){

    	
    	ModelAndView model2 = new ModelAndView("login");
    	
    	
    	model2.addObject("user",new Users());
        if(error != null){
            model2.addObject("error", "Invalid username and password");
        }

        if (logout !=null){
            model2.addObject("msg", "You have been logged out successfully");
        }

        return model2;
    }
    
    @RequestMapping(method=RequestMethod.POST,value="/validateUser")
    public String validate(@ModelAttribute("user") Users user, ModelAndView model, HttpSession session){
    	
    	if(service.validateUser(user.getUsername(), user.getPassword())){
    		 model.addObject("msg", "You have been logged out successfully");
    		 
    		 Customer cus = cusservice.getCustomerByUsername(user.getUsername());
    		 session.setAttribute("authority", authservice.getAuthoritiesOfUser(user.getUsername()));
    		 
    		 session.setAttribute("name", user.getUsername());
    		
    		 
    		return "productList";
    	}
    	model.addObject("error", "Invalid username and password");
    	return "login";
    }
    
    
    

    @RequestMapping("/about")
    public String about(){
        return "about";
    }
    
    
    @RequestMapping("/forgetpassword")
    public ModelAndView forgetPassword(@RequestParam("para") String para, HttpServletRequest request){
    	ModelAndView viw = new ModelAndView("ForgetPassword");
    	
    	System.out.println("Request >>>"+para);
    	if(para.equals("forg"))
    	{
    	viw.addObject("para","Forget" );
    	
    	}
    	else{
    		viw.addObject("para","Reset" );
    	}
        return viw;
    }
    
    
    @RequestMapping(method=RequestMethod.POST , value="resetPassword")
    public ModelAndView resetPassword(HttpServletRequest request){
    	ModelAndView model = new ModelAndView("ForgetPassword");
    	
    	String username = request.getParameter("username");
    	String password = request.getParameter("password");
    	String newPassword = request.getParameter("newpassword");
    	
    	if(password==null ){
    		password="' OR ''='";
    	}
    	
    	boolean resault = service.resetPasswordForUser(username, password, newPassword);
    	if(resault){
    		model.addObject("msg", "Password Reset successfully!");
    	}
    	else{
    		model.addObject("msg", "Unable to reset password!");
    	}
    	
    	return model;
    }
    
    @Bean
    public Users createUser(){
    	return new Users();
    }


} // The End of Class;
